import { Response } from 'express';
import { prisma } from '../lib/prisma';
import type { AuthRequest } from '../middleware/authenticate';

export async function getDashboard(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

  // Net worth: total INCOME - total EXPENSE
  const [totalIncome, totalExpenses] = await Promise.all([
    prisma.transaction.aggregate({
      where: { userId, type: 'INCOME' },
      _sum: { amount: true },
    }),
    prisma.transaction.aggregate({
      where: { userId, type: 'EXPENSE' },
      _sum: { amount: true },
    }),
  ]);

  const netWorth = Number(totalIncome._sum.amount ?? 0) - Number(totalExpenses._sum.amount ?? 0);

  // Monthly income vs expenses
  const [monthlyIncome, monthlyExpenses] = await Promise.all([
    prisma.transaction.aggregate({
      where: { userId, type: 'INCOME', date: { gte: startOfMonth, lte: endOfMonth } },
      _sum: { amount: true },
    }),
    prisma.transaction.aggregate({
      where: { userId, type: 'EXPENSE', date: { gte: startOfMonth, lte: endOfMonth } },
      _sum: { amount: true },
    }),
  ]);

  // Last 6 months income vs expenses
  const incomeVsExpenses = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const start = new Date(d.getFullYear(), d.getMonth(), 1);
    const end = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59);
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

    const [inc, exp] = await Promise.all([
      prisma.transaction.aggregate({ where: { userId, type: 'INCOME', date: { gte: start, lte: end } }, _sum: { amount: true } }),
      prisma.transaction.aggregate({ where: { userId, type: 'EXPENSE', date: { gte: start, lte: end } }, _sum: { amount: true } }),
    ]);

    incomeVsExpenses.push({
      month: months[d.getMonth()],
      income: Number(inc._sum.amount ?? 0),
      expenses: Number(exp._sum.amount ?? 0),
    });
  }

  // Spending by category (current month)
  const categoryGroups = await prisma.transaction.groupBy({
    by: ['category'],
    where: { userId, type: 'EXPENSE', date: { gte: startOfMonth, lte: endOfMonth } },
    _sum: { amount: true },
    orderBy: { _sum: { amount: 'desc' } },
  });

  const totalSpent = categoryGroups.reduce((sum, c) => sum + Number(c._sum.amount ?? 0), 0);
  const categoryColors = ['#3b82f6','#f59e0b','#10b981','#f43f5e','#8b5cf6','#06b6d4','#ec4899','#84cc16'];
  const categorySpending = categoryGroups.map((c, i) => ({
    category: c.category,
    amount: Number(c._sum.amount ?? 0),
    percentage: totalSpent > 0 ? Math.round((Number(c._sum.amount ?? 0) / totalSpent) * 100) : 0,
    color: categoryColors[i % categoryColors.length],
  }));

  // Budget health
  const budgets = await prisma.budget.findMany({ where: { userId } });
  const budgetHealth = await Promise.all(
    budgets.map(async (b) => {
      const spent = await prisma.transaction.aggregate({
        where: { userId, budgetId: b.id, type: 'EXPENSE', date: { gte: startOfMonth, lte: endOfMonth } },
        _sum: { amount: true },
      });
      const spentAmount = Number(spent._sum.amount ?? 0);
      const limit = Number(b.monthlyLimit);
      return {
        id: b.id,
        name: b.name,
        category: b.category,
        spent: spentAmount,
        limit,
        percentage: limit > 0 ? Math.round((spentAmount / limit) * 100) : 0,
        color: b.color,
        icon: b.icon,
      };
    })
  );

  // Top 5 recent transactions
  const recentTransactions = await prisma.transaction.findMany({
    where: { userId },
    orderBy: { date: 'desc' },
    take: 5,
    include: { budget: { select: { name: true, color: true } } },
  });

  // Upcoming bills (next 7 days)
  const in7Days = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const upcomingBills = await prisma.recurringBill.findMany({
    where: { userId, isActive: true, nextDueDate: { gte: now, lte: in7Days } },
    orderBy: { nextDueDate: 'asc' },
  });

  // Savings progress
  const savingsProgress = await prisma.savingsPot.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
  });

  const totalSaved = savingsProgress.reduce((s, p) => s + Number(p.currentAmount), 0);

  res.json({
    netWorth,
    totalAssets: Number(totalIncome._sum.amount ?? 0),
    totalLiabilities: Number(totalExpenses._sum.amount ?? 0),
    monthlyIncome: Number(monthlyIncome._sum.amount ?? 0),
    monthlyExpenses: Number(monthlyExpenses._sum.amount ?? 0),
    totalSaved,
    incomeVsExpenses,
    categorySpending,
    budgetHealth,
    recentTransactions: recentTransactions.map((t) => ({ ...t, amount: Number(t.amount) })),
    upcomingBills: upcomingBills.map((b) => ({ ...b, amount: Number(b.amount) })),
    savingsProgress: savingsProgress.map((p) => ({ ...p, currentAmount: Number(p.currentAmount), targetAmount: Number(p.targetAmount) })),
  });
}
