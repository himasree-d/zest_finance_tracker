import { Response } from 'express';
import { prisma } from '../lib/prisma';
import { recurringBillSchema } from '../lib/schemas';
import { HttpError } from '../middleware/errorHandler';
import type { AuthRequest } from '../middleware/authenticate';

export async function getBills(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const now = new Date();

  const bills = await prisma.recurringBill.findMany({
    where: { userId, isActive: true },
    orderBy: { nextDueDate: 'asc' },
  });

  const billsWithStatus = bills.map((b) => {
    let status = 'UPCOMING';
    const nextDue = new Date(b.nextDueDate);
    const lastPaid = b.lastPaidDate ? new Date(b.lastPaidDate) : null;
    const diffMs = nextDue.getTime() - now.getTime();
    const daysUntilDue = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

    if (lastPaid && lastPaid.getMonth() === now.getMonth() && lastPaid.getFullYear() === now.getFullYear() && b.frequency === 'MONTHLY') {
      status = 'PAID';
    } else if (daysUntilDue < 0) {
      status = 'OVERDUE';
    } else if (daysUntilDue <= 5) {
      status = 'DUE_SOON';
    }

    return {
      ...b,
      amount: Number(b.amount),
      status,
      daysUntilDue,
    };
  });

  res.json(billsWithStatus);
}

export async function createBill(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const body = recurringBillSchema.parse(req.body);

  const bill = await prisma.recurringBill.create({
    data: {
      ...body,
      userId,
      nextDueDate: new Date(body.nextDueDate),
    },
  });

  res.status(201).json({ ...bill, amount: Number(bill.amount) });
}

export async function updateBill(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;
  const body = recurringBillSchema.partial().parse(req.body);

  const existing = await prisma.recurringBill.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) throw new HttpError('Bill not found', 404);

  const updated = await prisma.recurringBill.update({
    where: { id },
    data: {
      ...body,
      ...(body.nextDueDate ? { nextDueDate: new Date(body.nextDueDate) } : {}),
    },
  });

  res.json({ ...updated, amount: Number(updated.amount) });
}

export async function deleteBill(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;

  const existing = await prisma.recurringBill.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) throw new HttpError('Bill not found', 404);

  await prisma.recurringBill.delete({ where: { id } });
  res.json({ message: 'Bill deleted' });
}

export async function markBillPaid(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;

  const bill = await prisma.recurringBill.findUnique({ where: { id } });
  if (!bill || bill.userId !== userId) throw new HttpError('Bill not found', 404);

  const now = new Date();
  const nextDue = new Date(bill.nextDueDate);
  let newNextDue = new Date(nextDue);

  if (bill.frequency === 'MONTHLY') {
    newNextDue.setMonth(newNextDue.getMonth() + 1);
  } else if (bill.frequency === 'WEEKLY') {
    newNextDue.setDate(newNextDue.getDate() + 7);
  } else if (bill.frequency === 'YEARLY') {
    newNextDue.setFullYear(newNextDue.getFullYear() + 1);
  }

  const updated = await prisma.recurringBill.update({
    where: { id },
    data: {
      lastPaidDate: now,
      nextDueDate: newNextDue,
    },
  });

  res.json({ ...updated, amount: Number(updated.amount) });
}
