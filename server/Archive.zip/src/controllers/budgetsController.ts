import { Response } from 'express';
import { prisma } from '../lib/prisma';
import { budgetSchema } from '../lib/schemas';
import { HttpError } from '../middleware/errorHandler';
import type { AuthRequest } from '../middleware/authenticate';

function getMonthRange(offset = 0): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() - offset, 1);
  const end = new Date(now.getFullYear(), now.getMonth() - offset + 1, 0, 23, 59, 59);
  return { start, end };
}

export async function getBudgets(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { start, end } = getMonthRange(0);

  const budgets = await prisma.budget.findMany({ where: { userId }, orderBy: { createdAt: 'asc' } });

  const budgetsWithSpent = await Promise.all(
    budgets.map(async (b) => {
      const spent = await prisma.transaction.aggregate({
        where: { userId, budgetId: b.id, type: 'EXPENSE', date: { gte: start, lte: end } },
        _sum: { amount: true },
      });
      const spentAmount = Number(spent._sum.amount ?? 0);
      const limit = Number(b.monthlyLimit);
      const recentTx = await prisma.transaction.findMany({
        where: { userId, budgetId: b.id },
        orderBy: { date: 'desc' },
        take: 3,
      });
      return {
        ...b,
        monthlyLimit: limit,
        spent: spentAmount,
        percentage: limit > 0 ? Math.round((spentAmount / limit) * 100) : 0,
        recentTransactions: recentTx.map((t) => ({ ...t, amount: Number(t.amount) })),
      };
    })
  );

  res.json(budgetsWithSpent);
}

export async function getBudgetDetails(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;

  const budget = await prisma.budget.findUnique({ where: { id } });
  if (!budget || budget.userId !== userId) throw new HttpError('Budget not found', 404);

  // Last 6 months sparkline data
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const sparkline = [];
  for (let i = 5; i >= 0; i--) {
    const { start, end } = getMonthRange(i);
    const now = new Date();
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const agg = await prisma.transaction.aggregate({
      where: { userId, budgetId: id, type: 'EXPENSE', date: { gte: start, lte: end } },
      _sum: { amount: true },
    });
    sparkline.push({ month: months[d.getMonth()], spent: Number(agg._sum.amount ?? 0) });
  }

  const { start, end } = getMonthRange(0);
  const spent = await prisma.transaction.aggregate({
    where: { userId, budgetId: id, type: 'EXPENSE', date: { gte: start, lte: end } },
    _sum: { amount: true },
  });
  const spentAmount = Number(spent._sum.amount ?? 0);
  const limit = Number(budget.monthlyLimit);

  const recentTransactions = await prisma.transaction.findMany({
    where: { userId, budgetId: id },
    orderBy: { date: 'desc' },
    take: 3,
  });

  res.json({
    ...budget,
    monthlyLimit: limit,
    spent: spentAmount,
    percentage: limit > 0 ? Math.round((spentAmount / limit) * 100) : 0,
    sparkline,
    recentTransactions: recentTransactions.map((t) => ({ ...t, amount: Number(t.amount) })),
  });
}

export async function createBudget(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const body = budgetSchema.parse(req.body);
  const budget = await prisma.budget.create({ data: { ...body, userId } });
  res.status(201).json({ ...budget, monthlyLimit: Number(budget.monthlyLimit), spent: 0, percentage: 0 });
}

export async function updateBudget(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;
  const body = budgetSchema.partial().parse(req.body);

  const existing = await prisma.budget.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) throw new HttpError('Budget not found', 404);

  const updated = await prisma.budget.update({ where: { id }, data: body });
  res.json({ ...updated, monthlyLimit: Number(updated.monthlyLimit) });
}

export async function deleteBudget(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;

  const existing = await prisma.budget.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) throw new HttpError('Budget not found', 404);

  await prisma.budget.delete({ where: { id } });
  res.json({ message: 'Budget deleted' });
}
