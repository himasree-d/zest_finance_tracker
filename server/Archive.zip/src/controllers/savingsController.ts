import { Response } from 'express';
import { prisma } from '../lib/prisma';
import { savingsPotSchema, potTransactionSchema } from '../lib/schemas';
import { HttpError } from '../middleware/errorHandler';
import type { AuthRequest } from '../middleware/authenticate';

export async function getPots(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const pots = await prisma.savingsPot.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    include: {
      potTransactions: {
        orderBy: { createdAt: 'desc' },
        take: 5,
      },
    },
  });

  res.json(
    pots.map((p) => ({
      ...p,
      targetAmount: Number(p.targetAmount),
      currentAmount: Number(p.currentAmount),
      potTransactions: p.potTransactions.map((pt) => ({ ...pt, amount: Number(pt.amount) })),
    }))
  );
}

export async function createPot(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const body = savingsPotSchema.parse(req.body);

  const pot = await prisma.savingsPot.create({
    data: {
      ...body,
      userId,
      targetDate: body.targetDate ? new Date(body.targetDate) : null,
    },
  });

  res.status(201).json({
    ...pot,
    targetAmount: Number(pot.targetAmount),
    currentAmount: Number(pot.currentAmount),
  });
}

export async function updatePot(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;
  const body = savingsPotSchema.partial().parse(req.body);

  const existing = await prisma.savingsPot.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) throw new HttpError('Pot not found', 404);

  const updated = await prisma.savingsPot.update({
    where: { id },
    data: {
      ...body,
      ...(body.targetDate !== undefined
        ? { targetDate: body.targetDate ? new Date(body.targetDate) : null }
        : {}),
    },
  });

  res.json({
    ...updated,
    targetAmount: Number(updated.targetAmount),
    currentAmount: Number(updated.currentAmount),
  });
}

export async function deletePot(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;

  const existing = await prisma.savingsPot.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) throw new HttpError('Pot not found', 404);

  await prisma.savingsPot.delete({ where: { id } });
  res.json({ message: 'Pot deleted' });
}

export async function addPotTransaction(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;
  const body = potTransactionSchema.parse(req.body);

  const pot = await prisma.savingsPot.findUnique({ where: { id } });
  if (!pot || pot.userId !== userId) throw new HttpError('Pot not found', 404);

  const currentAmount = Number(pot.currentAmount);
  if (body.type === 'WITHDRAW' && body.amount > currentAmount) {
    throw new HttpError('Cannot withdraw more than current amount', 400);
  }

  const newAmount =
    body.type === 'ADD' ? currentAmount + body.amount : currentAmount - body.amount;

  const [transaction, updatedPot] = await prisma.$transaction([
    prisma.potTransaction.create({
      data: {
        potId: id,
        amount: body.amount,
        type: body.type,
        note: body.note,
      },
    }),
    prisma.savingsPot.update({
      where: { id },
      data: { currentAmount: newAmount },
    }),
  ]);

  // Check if goal reached
  if (body.type === 'ADD' && newAmount >= Number(pot.targetAmount) && currentAmount < Number(pot.targetAmount)) {
    await prisma.notification.create({
      data: {
        userId,
        type: 'POT_GOAL_REACHED',
        title: 'Goal Reached! 🎉',
        message: `You have reached your savings goal for ${pot.name}!`,
      },
    });
  }

  res.status(201).json({
    transaction: { ...transaction, amount: Number(transaction.amount) },
    pot: { ...updatedPot, targetAmount: Number(updatedPot.targetAmount), currentAmount: Number(updatedPot.currentAmount) },
  });
}
