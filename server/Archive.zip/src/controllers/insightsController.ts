import { Response } from 'express';
import Anthropic from '@anthropic-ai/sdk';
import { prisma } from '../lib/prisma';
import type { AuthRequest } from '../middleware/authenticate';

const MOCK_INSIGHTS = {
  monthlySummary: "You've been managing your finances well this month. Your total spending is slightly below your average, primarily due to reduced expenses in shopping and entertainment. However, your dining out expenses have seen a noticeable uptick. Continuing this overall trend will help you reach your savings goals faster.",
  anomalies: [
    {
      category: "Dining",
      currentAmount: 450,
      averageAmount: 200,
      percentageChange: 125,
      message: "You spent 125% more on dining this month vs your 3-month average."
    }
  ],
  suggestions: [
    {
      title: "Optimize Subscriptions",
      description: "You have 3 active streaming subscriptions. Consider rotating them to save money.",
      potentialSavings: 30
    },
    {
      title: "Grocery Shopping",
      description: "Buying in bulk for non-perishables could reduce your monthly grocery bill by 10%.",
      potentialSavings: 45
    }
  ],
  streaks: [
    {
      type: "Budget",
      description: "You've stayed under your 'Transport' budget for 3 months in a row!",
      count: 3,
      icon: "🚗"
    }
  ]
};

export async function getInsights(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const apiKey = process.env.ANTHROPIC_API_KEY;

  if (!apiKey || apiKey === 'your-anthropic-api-key') {
    // If no real API key, return mock data for demo purposes
    res.json(MOCK_INSIGHTS);
    return;
  }

  const now = new Date();
  const threeMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 3, 1);
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  // 1. Get transactions for last 3 months
  const recentTransactions = await prisma.transaction.findMany({
    where: { userId, type: 'EXPENSE', date: { gte: threeMonthsAgo } },
  });

  // 2. Compute category totals
  const categoryStats: Record<string, { current: number; historical: number[] }> = {};
  
  recentTransactions.forEach(t => {
    const isCurrentMonth = t.date >= startOfMonth;
    const amount = Number(t.amount);
    
    if (!categoryStats[t.category]) {
      categoryStats[t.category] = { current: 0, historical: [] };
    }
    
    if (isCurrentMonth) {
      categoryStats[t.category].current += amount;
    } else {
      categoryStats[t.category].historical.push(amount);
    }
  });

  // 3. Find anomalies
  const anomalies = [];
  for (const [cat, stats] of Object.entries(categoryStats)) {
    if (stats.historical.length > 0 && stats.current > 0) {
      const avg = stats.historical.reduce((a, b) => a + b, 0) / Math.max(1, Math.floor(stats.historical.length / (recentTransactions.length > 0 ? 3 : 1))); // rough avg per month
      
      if (avg > 0 && stats.current > avg * 1.5) { // 50% increase
        const percentageChange = Math.round(((stats.current - avg) / avg) * 100);
        anomalies.push({
          category: cat,
          currentAmount: stats.current,
          averageAmount: Math.round(avg),
          percentageChange,
          message: `You spent ${percentageChange}% more on ${cat} this month vs your historical average.`
        });
      }
    }
  }

  // 4. Generate summary with Claude
  try {
    const anthropic = new Anthropic({ apiKey });
    
    const prompt = `
      You are an expert financial advisor AI for an app called Zest.
      Analyze this user's spending data and provide a short, encouraging, and insightful 3-4 sentence summary of their current month's financial health.
      Focus on trends and positive reinforcement.
      
      Data summary:
      - Current month categories: ${JSON.stringify(Object.fromEntries(Object.entries(categoryStats).map(([k, v]) => [k, v.current])))}
      - Noteworthy anomalies: ${JSON.stringify(anomalies.map(a => a.category))}
      
      Return ONLY the summary text, no conversational filler.
    `;

    const msg = await anthropic.messages.create({
      model: 'claude-3-5-sonnet-20240620',
      max_tokens: 300,
      messages: [{ role: 'user', content: prompt }]
    });

    const monthlySummary = msg.content[0].type === 'text' ? msg.content[0].text : MOCK_INSIGHTS.monthlySummary;

    res.json({
      monthlySummary,
      anomalies,
      suggestions: MOCK_INSIGHTS.suggestions, // Keep suggestions mock for now unless we prompt Claude for JSON
      streaks: MOCK_INSIGHTS.streaks
    });
  } catch (error) {
    console.error("Anthropic API Error:", error);
    // Fallback to mock on error
    res.json(MOCK_INSIGHTS);
  }
}
