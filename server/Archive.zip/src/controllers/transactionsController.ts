import { Response } from 'express';
import { prisma } from '../lib/prisma';
import { transactionSchema } from '../lib/schemas';
import { HttpError } from '../middleware/errorHandler';
import type { AuthRequest } from '../middleware/authenticate';

export async function getTransactions(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const {
    search, category, type, dateFrom, dateTo,
    amountMin, amountMax, sortBy = 'date', sortOrder = 'desc',
    page = '1', pageSize = '10',
  } = req.query as Record<string, string>;

  const where: Record<string, unknown> = { userId };
  if (search) where.name = { contains: search, mode: 'insensitive' };
  if (category) where.category = category;
  if (type) where.type = type;
  if (dateFrom || dateTo) {
    where.date = {
      ...(dateFrom ? { gte: new Date(dateFrom) } : {}),
      ...(dateTo ? { lte: new Date(dateTo) } : {}),
    };
  }
  if (amountMin || amountMax) {
    where.amount = {
      ...(amountMin ? { gte: parseFloat(amountMin) } : {}),
      ...(amountMax ? { lte: parseFloat(amountMax) } : {}),
    };
  }

  const orderBy: Record<string, string> = {};
  if (sortBy === 'date') orderBy.date = sortOrder;
  else if (sortBy === 'amount') orderBy.amount = sortOrder;
  else if (sortBy === 'name') orderBy.name = sortOrder;

  const pageNum = parseInt(page, 10);
  const size = Math.min(parseInt(pageSize, 10), 100);
  const skip = (pageNum - 1) * size;

  const [transactions, total] = await Promise.all([
    prisma.transaction.findMany({
      where,
      orderBy,
      skip,
      take: size,
      include: { budget: { select: { name: true, color: true, icon: true } } },
    }),
    prisma.transaction.count({ where }),
  ]);

  res.json({
    data: transactions.map((t) => ({ ...t, amount: Number(t.amount) })),
    total,
    page: pageNum,
    pageSize: size,
    totalPages: Math.ceil(total / size),
  });
}

export async function createTransaction(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const body = transactionSchema.parse(req.body);

  const transaction = await prisma.transaction.create({
    data: { ...body, userId, amount: body.amount, date: new Date(body.date) },
    include: { budget: { select: { name: true, color: true, icon: true } } },
  });

  res.status(201).json({ ...transaction, amount: Number(transaction.amount) });
}

export async function updateTransaction(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;
  const body = transactionSchema.partial().parse(req.body);

  const existing = await prisma.transaction.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) throw new HttpError('Transaction not found', 404);

  const updated = await prisma.transaction.update({
    where: { id },
    data: { ...body, ...(body.date ? { date: new Date(body.date) } : {}) },
    include: { budget: { select: { name: true, color: true, icon: true } } },
  });

  res.json({ ...updated, amount: Number(updated.amount) });
}

export async function deleteTransaction(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;

  const existing = await prisma.transaction.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) throw new HttpError('Transaction not found', 404);

  await prisma.transaction.delete({ where: { id } });
  res.json({ message: 'Transaction deleted' });
}

export async function bulkDeleteTransactions(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { ids } = req.body as { ids: string[] };
  if (!Array.isArray(ids) || ids.length === 0) throw new HttpError('No IDs provided', 400);

  await prisma.transaction.deleteMany({ where: { id: { in: ids }, userId } });
  res.json({ message: `Deleted ${ids.length} transactions` });
}

export async function exportTransactions(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { category, type, dateFrom, dateTo } = req.query as Record<string, string>;

  const where: Record<string, unknown> = { userId };
  if (category) where.category = category;
  if (type) where.type = type;
  if (dateFrom || dateTo) {
    where.date = {
      ...(dateFrom ? { gte: new Date(dateFrom) } : {}),
      ...(dateTo ? { lte: new Date(dateTo) } : {}),
    };
  }

  const transactions = await prisma.transaction.findMany({
    where,
    orderBy: { date: 'desc' },
  });

  const header = 'Date,Name,Category,Type,Amount,Note,Merchant\n';
  const rows = transactions.map((t) =>
    [
      new Date(t.date).toISOString().split('T')[0],
      `"${t.name.replace(/"/g, '""')}"`,
      t.category,
      t.type,
      Number(t.amount).toFixed(2),
      `"${(t.note ?? '').replace(/"/g, '""')}"`,
      `"${(t.merchant ?? '').replace(/"/g, '""')}"`,
    ].join(',')
  ).join('\n');

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="transactions.csv"');
  res.send(header + rows);
}
