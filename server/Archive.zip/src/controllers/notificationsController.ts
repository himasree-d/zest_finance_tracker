import { Response } from 'express';
import { prisma } from '../lib/prisma';
import { HttpError } from '../middleware/errorHandler';
import type { AuthRequest } from '../middleware/authenticate';

export async function getNotifications(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const notifications = await prisma.notification.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
  res.json(notifications);
}

export async function markRead(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;

  const notification = await prisma.notification.findUnique({ where: { id } });
  if (!notification || notification.userId !== userId) throw new HttpError('Not found', 404);

  const updated = await prisma.notification.update({
    where: { id },
    data: { read: true },
  });

  res.json(updated);
}

export async function markAllRead(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  await prisma.notification.updateMany({
    where: { userId, read: false },
    data: { read: true },
  });
  res.json({ message: 'All notifications marked as read' });
}

export async function deleteNotification(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const { id } = req.params;

  const notification = await prisma.notification.findUnique({ where: { id } });
  if (!notification || notification.userId !== userId) throw new HttpError('Not found', 404);

  await prisma.notification.delete({ where: { id } });
  res.json({ message: 'Deleted' });
}

export async function clearAll(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  await prisma.notification.deleteMany({ where: { userId } });
  res.json({ message: 'All notifications cleared' });
}
