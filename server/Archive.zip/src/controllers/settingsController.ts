import { Response } from 'express';
import bcrypt from 'bcrypt';
import { prisma } from '../lib/prisma';
import { settingsSchema, profileSchema } from '../lib/schemas';
import { HttpError } from '../middleware/errorHandler';
import type { AuthRequest } from '../middleware/authenticate';

export async function getSettings(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, email: true, name: true, avatar: true },
  });
  
  const settings = await prisma.userSettings.findUnique({
    where: { userId },
  });

  res.json({ user, settings });
}

export async function updateSettings(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const body = settingsSchema.parse(req.body);

  const settings = await prisma.userSettings.upsert({
    where: { userId },
    update: body,
    create: { userId, ...body },
  });

  res.json(settings);
}

export async function updateProfile(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  const body = profileSchema.parse(req.body);

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) throw new HttpError('User not found', 404);

  const dataToUpdate: any = {};
  if (body.name) dataToUpdate.name = body.name;
  if (body.email) dataToUpdate.email = body.email;
  if (body.avatar !== undefined) dataToUpdate.avatar = body.avatar;

  if (body.newPassword) {
    if (!body.currentPassword) throw new HttpError('Current password required', 400);
    const valid = await bcrypt.compare(body.currentPassword, user.password);
    if (!valid) throw new HttpError('Invalid current password', 401);
    dataToUpdate.password = await bcrypt.hash(body.newPassword, 12);
  }

  const updated = await prisma.user.update({
    where: { id: userId },
    data: dataToUpdate,
    select: { id: true, email: true, name: true, avatar: true },
  });

  res.json(updated);
}

export async function exportData(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  
  const [transactions, budgets, pots, bills] = await Promise.all([
    prisma.transaction.findMany({ where: { userId } }),
    prisma.budget.findMany({ where: { userId } }),
    prisma.savingsPot.findMany({ where: { userId } }),
    prisma.recurringBill.findMany({ where: { userId } }),
  ]);

  const data = {
    exportDate: new Date(),
    transactions,
    budgets,
    pots,
    bills
  };

  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', 'attachment; filename="zest-data.json"');
  res.send(JSON.stringify(data, null, 2));
}

export async function deleteAccount(req: AuthRequest, res: Response): Promise<void> {
  const userId = req.userId!;
  // Cascade delete handles related records
  await prisma.user.delete({ where: { id: userId } });
  
  res.clearCookie('access_token');
  res.clearCookie('refresh_token', { path: '/api/auth/refresh' });
  
  res.json({ message: 'Account deleted' });
}
