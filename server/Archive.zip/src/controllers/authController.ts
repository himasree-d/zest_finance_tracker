import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { prisma } from '../lib/prisma';
import { registerSchema, loginSchema } from '../lib/schemas';
import { HttpError } from '../middleware/errorHandler';
import type { AuthRequest } from '../middleware/authenticate';

const SALT_ROUNDS = 12;
const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY = '7d';
const REFRESH_TOKEN_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000;

function generateAccessToken(userId: string, email: string, name: string): string {
  const secret = process.env.JWT_ACCESS_SECRET;
  if (!secret) throw new Error('JWT_ACCESS_SECRET not set');
  return jwt.sign({ userId, email, name }, secret, { expiresIn: ACCESS_TOKEN_EXPIRY });
}

function generateRefreshToken(userId: string): string {
  const secret = process.env.JWT_REFRESH_SECRET;
  if (!secret) throw new Error('JWT_REFRESH_SECRET not set');
  return jwt.sign({ userId }, secret, { expiresIn: REFRESH_TOKEN_EXPIRY });
}

function setAuthCookies(res: Response, accessToken: string, refreshToken: string): void {
  const isProd = process.env.NODE_ENV === 'production';

  res.cookie('access_token', accessToken, {
    httpOnly: true,
    secure: isProd,
    sameSite: isProd ? 'strict' : 'lax',
    maxAge: 15 * 60 * 1000, // 15 min
  });

  res.cookie('refresh_token', refreshToken, {
    httpOnly: true,
    secure: isProd,
    sameSite: isProd ? 'strict' : 'lax',
    maxAge: REFRESH_TOKEN_EXPIRY_MS,
    path: '/api/auth/refresh',
  });
}

export async function register(req: Request, res: Response): Promise<void> {
  const body = registerSchema.parse(req.body);

  const existing = await prisma.user.findUnique({ where: { email: body.email } });
  if (existing) throw new HttpError('Email already in use', 409);

  const hashed = await bcrypt.hash(body.password, SALT_ROUNDS);

  const user = await prisma.user.create({
    data: {
      name: body.name,
      email: body.email,
      password: hashed,
      settings: { create: {} },
    },
    select: { id: true, email: true, name: true, avatar: true, createdAt: true },
  });

  const accessToken = generateAccessToken(user.id, user.email, user.name);
  const refreshToken = generateRefreshToken(user.id);

  await prisma.refreshToken.create({
    data: {
      token: refreshToken,
      userId: user.id,
      expiresAt: new Date(Date.now() + REFRESH_TOKEN_EXPIRY_MS),
    },
  });

  setAuthCookies(res, accessToken, refreshToken);

  res.status(201).json({ user });
}

export async function login(req: Request, res: Response): Promise<void> {
  const body = loginSchema.parse(req.body);

  const user = await prisma.user.findUnique({ where: { email: body.email } });
  if (!user) throw new HttpError('Invalid credentials', 401);

  const valid = await bcrypt.compare(body.password, user.password);
  if (!valid) throw new HttpError('Invalid credentials', 401);

  const accessToken = generateAccessToken(user.id, user.email, user.name);
  const refreshToken = generateRefreshToken(user.id);

  await prisma.refreshToken.create({
    data: {
      token: refreshToken,
      userId: user.id,
      expiresAt: new Date(Date.now() + REFRESH_TOKEN_EXPIRY_MS),
    },
  });

  setAuthCookies(res, accessToken, refreshToken);

  res.json({
    user: { id: user.id, email: user.email, name: user.name, avatar: user.avatar, createdAt: user.createdAt },
  });
}

export async function refresh(req: Request, res: Response): Promise<void> {
  const token = req.cookies.refresh_token as string | undefined;
  if (!token) throw new HttpError('Refresh token required', 401);

  const secret = process.env.JWT_REFRESH_SECRET;
  if (!secret) throw new Error('JWT_REFRESH_SECRET not set');

  let payload: { userId: string };
  try {
    payload = jwt.verify(token, secret) as { userId: string };
  } catch {
    throw new HttpError('Invalid or expired refresh token', 401);
  }

  const storedToken = await prisma.refreshToken.findUnique({ where: { token } });
  if (!storedToken || storedToken.expiresAt < new Date()) {
    throw new HttpError('Refresh token expired or revoked', 401);
  }

  // Delete old refresh token (rotation)
  await prisma.refreshToken.delete({ where: { token } });

  const user = await prisma.user.findUnique({ where: { id: payload.userId } });
  if (!user) throw new HttpError('User not found', 401);

  const newAccessToken = generateAccessToken(user.id, user.email, user.name);
  const newRefreshToken = generateRefreshToken(user.id);

  await prisma.refreshToken.create({
    data: {
      token: newRefreshToken,
      userId: user.id,
      expiresAt: new Date(Date.now() + REFRESH_TOKEN_EXPIRY_MS),
    },
  });

  setAuthCookies(res, newAccessToken, newRefreshToken);
  res.json({ message: 'Token refreshed' });
}

export async function logout(req: AuthRequest, res: Response): Promise<void> {
  const token = req.cookies.refresh_token as string | undefined;

  if (token) {
    await prisma.refreshToken.deleteMany({ where: { token } });
  }

  res.clearCookie('access_token');
  res.clearCookie('refresh_token', { path: '/api/auth/refresh' });

  res.json({ message: 'Logged out successfully' });
}

export async function getMe(req: AuthRequest, res: Response): Promise<void> {
  const user = await prisma.user.findUnique({
    where: { id: req.userId },
    select: { id: true, email: true, name: true, avatar: true, createdAt: true },
  });

  if (!user) throw new HttpError('User not found', 404);

  res.json({ user });
}
